﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tao.DevIl;
using Tao.FreeGlut;
using Tao.OpenGl;

namespace Gurieva_Alexandra_PRI_120_PKG_KP
{
    public partial class Form1 : Form
    {
        //Управление положением пользователя
        double angle = 3, angleX = -96, angleY = 0, angleZ = -30;
        double sizeX = 1, sizeY = 1, sizeZ = 1;
        double translateX = -9, translateY = -60, translateZ = -10;
        double cameraSpeed;


        string desktopTexture = "desktop.jpg";
        string calendarTexture = "calendar.jpg";

        uint desktopSign, calendarSign;
        int imageId;

        Office office = new Office();
        Cursor cursor = new Cursor(0, 0);
        Worker worker = new Worker(0, WorkerState.Calm, 0);
        Plane plane = new Plane(0, PlaneState.Waiting);
        Inkwell inkwell = new Inkwell(true, false);
        Pendulum pendulum = new Pendulum(new Coord[5] { new Coord(-6, 6,BallState.Down), new Coord(0,0, BallState.Calm), new Coord(0, 0, BallState.Calm), new Coord(0, 0, BallState.Calm), new Coord(0, 0, BallState.Calm) });

        //Проигрывание аудио при выигрыше в игре со знаками
        public WMPLib.WindowsMediaPlayer WMP = new WMPLib.WindowsMediaPlayer();

        public void Draw()
        {
            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);
            Gl.glClearColor(255, 255, 255, 1);
            Gl.glLoadIdentity();
            Gl.glPushMatrix();
            Gl.glRotated(angleX, 1, 0, 0);
            Gl.glRotated(angleY, 0, 1, 0);
            Gl.glRotated(angleZ, 0, 0, 1);
            Gl.glTranslated(translateX, translateY, translateZ);
            Gl.glScaled(sizeX, sizeY, sizeZ);
            office.drawWalls();
            office.drawFloor();
            office.drawCalendar(calendarSign);
            drawFirstTable();
            drawSecondTable();

            
            if (comboBox1.SelectedIndex == 3)
            {
                office.drawPlane(plane);
                if (plane.planeState != PlaneState.Waiting && plane.planeState != PlaneState.Lying) animatePlane();
            }


            Gl.glPopMatrix();
            Gl.glFlush();
            AnT.Invalidate();
        }

        private void animatePlane()
        {
            switch (plane.planeState)
            {
                case PlaneState.Flying:
                    if (plane.translate >= 40)
                    {
                        plane.planeState = PlaneState.Falling;
                        worker.workerState = WorkerState.RotatingTo;
                        plane.translate = 0;
                        label7.Text = "О-о-у...";
                    } else
                    plane.translate+=7;
                    break;
                case PlaneState.Falling:
                    if (plane.translate >= 42)
                    {
                        plane.planeState = PlaneState.Lying;
                        plane.translate = 0;
                    }
                    else plane.translate += 5;
                    break;

            }
            
        }

        private void drawFirstTable()
        {
            office.drawTable(90, 0, 0);
            office.drawComputer(80, 0, 0, desktopSign);
            office.drawCursor(cursor.translateX, cursor.translateZ);
            office.drawChair(worker);

            checkWorkerPosition();
        }

        private void drawSecondTable()
        {
            office.drawTable(-120, 70, 90);
            office.drawComputer(-60, -80, 90, desktopSign);
            office.drawInkwell(inkwell);
            office.drawPendulum(pendulum);
            moveBallsOfPendulum(pendulum.balls);
        }

        private void moveBallsOfPendulum(Coord[] balls)
        {
            for (int i = 0; i <5; i++)
            {
                int y = 0;
                if (i == 0 || i == 4) y = -5;
                else if (i == 1 || i == 3) y = -3;
                else y = -1;

                if (balls[i].ballState == BallState.Up)
                {
                    if (balls[i].translateY <= y)
                    {
                        balls[i].ballState = BallState.Down;
                    }
                    else
                    {
                        double power = 1.5;
                        if (i == 0 || i == 4) power = 3;
                        balls[i].translateY-=power;
                        balls[i].translateZ+=power;
                    }
                }
                else if (balls[i].ballState == BallState.Down)
                {
                    if (balls[i].translateY >= 0)
                    {
                        balls[i].ballState = BallState.Calm;
                        if (i == 0 || i == 1)
                        {
                            balls[3].ballState = balls[4].ballState = BallState.Up;
                        } else if (i == 4 || i == 3)
                        {
                            balls[0].ballState = balls[1].ballState = balls[2].ballState = BallState.Up;
                        }
                    }
                    else
                    {
                        double power = 1.5;
                        if (i == 0 || i == 4) power = 3;
                        balls[i].translateY+=power;
                        balls[i].translateZ-=power;
                    }
                }
            }
        }


        private void checkWorkerPosition()
        {
            switch (worker.workerState)
            {
                case WorkerState.RotatingTo:
                    if (worker.rotate > 45)
                    {
                        worker.workerState = WorkerState.Speaking;
                        label7.Text = "Кажется, он злится...";
                    }
                    else worker.rotate++;
                    break;
                case WorkerState.Speaking:
                    if (worker.speakingTime > 10)
                    {
                        worker.workerState = WorkerState.RotatingFrom;
                        worker.speakingTime = 0;
                        label7.Text = "Пронесло:)";
                    }
                    else worker.speakingTime++;
                    break;
                case WorkerState.RotatingFrom:
                    if (worker.rotate <= 0)
                    {
                        worker.workerState = WorkerState.Calm;
                        worker.rotate = 0;
                        label7.Text = "Больше его не трогаем...";
                    }
                    else worker.rotate--;
                    break;
            }
        }

        public Form1()
        {
            InitializeComponent();
            AnT.InitializeContexts();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    angle = 3; angleX = -50; angleY = 0; angleZ = -30;
                    sizeX = 1; sizeY = 1; sizeZ = 1;
                    translateX = -70; translateY = 200; translateZ = -120;
                    initFirstPosition();
                    break;
                case 1:
                    translateX = 0; translateY = 120; translateZ = -90;
                    angle = 3; angleX = -90; angleY = 0; angleZ = 0;
                    initSecondPosition();
                    break;
                case 2:
                    translateX = -90; translateY = 80; translateZ = -60;
                    angle = 3; angleX = -90; angleY = 0; angleZ = 0;
                    initThirdPosition();
                    break;
                case 3:
                    translateX = -200; translateY = 80; translateZ = -150;
                    angle = 3; angleX = -35; angleY = 0; angleZ = -90;
                    initFourthPosition();
                    break;
                case 4:
                    angle = 3; angleX = -50; angleY = 0; angleZ = -50;
                    translateX = -30; translateY = 180; translateZ = -120;
                    initFifthPosition();
                    break;
            }
            AnT.Focus();
        }

        private void RenderTimer_Tick(object sender, EventArgs e)
        {
            Draw();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            plane.planeState = PlaneState.Flying;
            button1.Visible = false;
        }

        private void initFirstPosition()
        {
            label6.Visible = false;
            button1.Visible = false;
            label8.Visible = true;
            label7.Text = "Тебе повезло - ты не такой, как все";
            label8.Text = "Ты работаешь в офисе";
        }

        private void initSecondPosition()
        {
            label6.Visible = false;
            button1.Visible = false;
            label8.Visible = false;
            label7.Text = "Я календарь переверну...";
        }

        private void initThirdPosition()
        {
            label6.Visible = true;
            label6.Text = "FTGH - перемещение курсора";
            label8.Visible = false;
            label7.Text = "Компьютер в компьютере, жесть";
        }

        private void initFourthPosition()
        {
            label6.Visible = false;
            label7.Text = "Больше его не трогаем...";
            if (plane.planeState == PlaneState.Waiting)
            {
                button1.Visible = true;
                button1.Text = "Запустить самолётик";
                label7.Text = "Интересно, что будет, если запустить его?";
            }
            
            label8.Visible = false;
            
        }

        private void initFifthPosition()
        {
            label6.Visible = true;
            label6.Text = "TG - уронить/поднять чернильницу";
            button1.Visible = false;
            label8.Visible = false;
            label7.Text = "Маятник хорош";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            AnT.Focus();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown1.Value > 0)
                cameraSpeed = (double)numericUpDown1.Value;
            AnT.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WMP.URL = @"somebody.mp3";
            WMP.controls.play();
            // инициализация openGL (glut)
            Glut.glutInit();
            Glut.glutInitDisplayMode(Glut.GLUT_RGB | Glut.GLUT_DOUBLE | Glut.GLUT_DEPTH);

            Il.ilInit();
            Il.ilEnable(Il.IL_ORIGIN_SET);

            // цвет очистки окна
            Gl.glClearColor(255, 255, 255, 1);

            // настройка порта просмотра
            Gl.glViewport(0, 0, AnT.Width, AnT.Height);

            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();
            Glu.gluPerspective(60, (float)AnT.Width / (float)AnT.Height, 0.1, 900);
            Gl.glMatrixMode(Gl.GL_MODELVIEW);
            Gl.glLoadIdentity();
            Gl.glEnable(Gl.GL_DEPTH_TEST);

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            cameraSpeed = 5;

            desktopSign = genImage(desktopTexture);
            calendarSign = genImage(calendarTexture);

            
            RenderTimer.Start();
        }

        private void AnT_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.W:
                    translateY -= cameraSpeed;
                    break;
                case Keys.S:
                    translateY += cameraSpeed;
                    break;
                case Keys.A:
                    translateX += cameraSpeed;
                    break;
                case Keys.D:
                    translateX -= cameraSpeed;
                    break;
                case Keys.R:
                    switch (comboBox2.SelectedIndex)
                    {
                        case 0:
                            angleX += angle;

                            break;
                        case 1:
                            angleY += angle;

                            break;
                        case 2:
                            angleZ += angle;

                            break;
                        default:
                            break;
                    }
                    break;
                case Keys.E:
                    switch (comboBox2.SelectedIndex)
                    {
                        case 0:
                            angleX -= angle;
                            break;
                        case 1:
                            angleY -= angle;
                            break;
                        case 2:
                            angleZ -= angle;
                            break;
                        default:
                            break;
                    }
                    break;
                case Keys.H:
                    switch (comboBox1.SelectedIndex)
                    {
                        case 2:
                            if (cursor.translateX <4) 
                                cursor.translateX++ ;
                            break;
                    }
                    break;
                case Keys.F:
                    switch (comboBox1.SelectedIndex)
                    {
                        case 2:
                            if (cursor.translateX > -30)
                                cursor.translateX--;
                            break;
                    }
                    break;
                case Keys.T:
                    switch (comboBox1.SelectedIndex)
                    {
                        case 2:
                            if (cursor.translateZ <2)
                                cursor.translateZ++;
                            break;
                        case 4:
                            inkwell.isStay = true;
                            break;
                    }
                    break;
                case Keys.G:
                    switch (comboBox1.SelectedIndex)
                    {
                        case 2:
                            if (cursor.translateZ >-15)
                                cursor.translateZ--;
                            break;
                        case 4:
                            inkwell.isStay = false;
                            inkwell.isSpilled = true;
                            break;
                    }
                    break;

            }
        }

        private uint genImage(string image)
        {
            uint sign = 0;
            Il.ilGenImages(1, out imageId);
            Il.ilBindImage(imageId);
            if (Il.ilLoadImage(image))
            {
                int width = Il.ilGetInteger(Il.IL_IMAGE_WIDTH);
                int height = Il.ilGetInteger(Il.IL_IMAGE_HEIGHT);
                int bitspp = Il.ilGetInteger(Il.IL_IMAGE_BITS_PER_PIXEL);
                switch (bitspp)
                {
                    case 24:
                        sign = MakeGlTexture(Gl.GL_RGB, Il.ilGetData(), width, height);
                        break;
                    case 32:
                        sign = MakeGlTexture(Gl.GL_RGBA, Il.ilGetData(), width, height);
                        break;
                }
            }
            Il.ilDeleteImages(1, ref imageId);
            return sign;
        }

        private static uint MakeGlTexture(int Format, IntPtr pixels, int w, int h)
        {
            uint texObject;
            Gl.glGenTextures(1, out texObject);
            Gl.glPixelStorei(Gl.GL_UNPACK_ALIGNMENT, 1);
            Gl.glBindTexture(Gl.GL_TEXTURE_2D, texObject);
            Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_WRAP_S, Gl.GL_REPEAT);
            Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_WRAP_T, Gl.GL_REPEAT);
            Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MAG_FILTER, Gl.GL_LINEAR);
            Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MIN_FILTER, Gl.GL_LINEAR);
            Gl.glTexEnvf(Gl.GL_TEXTURE_ENV, Gl.GL_TEXTURE_ENV_MODE, Gl.GL_REPLACE);
            switch (Format)
            {

                case Gl.GL_RGB:
                    Gl.glTexImage2D(Gl.GL_TEXTURE_2D, 0, Gl.GL_RGB, w, h, 0, Gl.GL_RGB, Gl.GL_UNSIGNED_BYTE, pixels);
                    break;

                case Gl.GL_RGBA:
                    Gl.glTexImage2D(Gl.GL_TEXTURE_2D, 0, Gl.GL_RGBA, w, h, 0, Gl.GL_RGBA, Gl.GL_UNSIGNED_BYTE, pixels);
                    break;

            }
            return texObject;
        }
    }

    public class Cursor
    {
        public double translateX;
        public double translateZ;

        public Cursor(double translateX, double translateZ)
        {
            this.translateX = translateX;
            this.translateZ = translateZ;
        }
    }

    public class Worker
    {
        public int rotate;
        public WorkerState workerState;
        public int speakingTime;


        public Worker(int rotate, WorkerState workerState, int speakingTime)
        {
            this.rotate = rotate;
            this.workerState = workerState;
            this.speakingTime = speakingTime;
        }
    }
    public enum WorkerState
    {
        Calm,
        RotatingTo,
        Speaking,
        RotatingFrom
    }

    public class Plane
    {
        public double translate;
        public PlaneState planeState;

        public Plane(double translate, PlaneState planeState)
        {
            this.translate = translate;
            this.planeState = planeState;
        }
    }

    public enum PlaneState
    {
        Waiting,
        Flying,
        Falling,
        Lying
    }

    public class Inkwell
    {
        public bool isStay;
        public bool isSpilled;

        public Inkwell(bool isStay, bool isSpilled)
        {
            this.isStay = isStay;
            this.isSpilled = isSpilled;
        }
    }

    public class Coord
    {
        public double translateY;
        public double translateZ;
        public BallState ballState;

        public Coord(double translateY, double translateZ,
            BallState ballState)
        {
            this.translateY = translateY;
            this.translateZ = translateZ;
            this.ballState = ballState;
        }
    }

    public enum BallState
    {
        Calm,
        Up,
        Down
    }

    public class Pendulum
    {
        public Coord[] balls;
        public Pendulum(Coord[] balls)
        {
            this.balls = balls;
        }
    }
}
