﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tao.FreeGlut;
using Tao.OpenGl;
using System.Drawing;
using System.Windows.Forms;

namespace Gurieva_Alexandra_PRI_120_PKG_KP
{
    class Office
    {
        private float deltaColor;

        //Пол
        public void drawFloor()
        {
            Gl.glPushMatrix();
            setColor(0.34f, 0.34f, 0.27f);
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glVertex3d(-100, 5, 0);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(-100, -300, 0);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(200, -300, 0);
            Gl.glTexCoord2f(1, 1);
            Gl.glVertex3d(200, 5, 0);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();
            Gl.glPopMatrix();
        }

        //Стены
        public void drawWalls()
        {
            Gl.glPushMatrix();
            setColor(0.92f, 0.9f, 0.35f);
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glVertex3d(-100, 5, 200);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(-100, 5, 0);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(200, 5, 0);
            Gl.glTexCoord2f(1, 1);
            Gl.glVertex3d(200, 5, 200);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();
            Gl.glPopMatrix();

            Gl.glPushMatrix();
            Gl.glTranslated(-90, -100, 0);
            Gl.glRotated(90, 0, 0, 1);
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glVertex3d(-200, 5, 200);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(-200, 5, 0);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(200, 5, 0);
            Gl.glTexCoord2f(1, 1);
            Gl.glVertex3d(200, 5, 200);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();

            Gl.glLineWidth(6f);

            setColor(0.92f, 0.5f, 0.05f);
            Gl.glTranslated(99, 2, 0);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3d(0, 0, 0);
            Gl.glVertex3d(0, 0, 200);
            Gl.glEnd();
            Gl.glPopMatrix();
        }

        //Стол
        public void drawTable(double translateX, double translateY, double rotate)
        {
            Gl.glPushMatrix();
            Gl.glRotated(rotate, 0, 0, 1);
            Gl.glPushMatrix();
            setColor(0.27f, 0.15f, 0.05f);
            Gl.glTranslated(0 + translateX, -30 + translateY, 30);

            Gl.glScalef(4, 2f, 0.3f);
            Glut.glutSolidCube(30);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireCube(30);
            Gl.glPopMatrix();

            for (int i = 0; i < 4; i++)
            {
                Gl.glPushMatrix();
                setColor(0.27f, 0.15f, 0.05f);
                int x, y = 0;
                if (i == 0) {
                    x = -50;
                    y = -5;
                }
                else if (i == 1)
                {
                    x = -50;
                    y = -45;
                }
                else if (i == 2)
                {
                    x = 50;
                    y = -5;
                } else
                {
                    x = 50;
                    y = -45;
                }

                Gl.glTranslated(x + translateX, y + translateY, 18);
                Gl.glScalef(0.3f, 0.3f, 1f);
                Glut.glutSolidCube(30);
                Gl.glColor3f(0, 0, 0);
                Gl.glLineWidth(2f);
                Glut.glutWireCube(30);
                Gl.glPopMatrix();
            }


            Gl.glPopMatrix();
        }

        //Компьютер
        public void drawComputer(double translateX, double translateY, double rotate,
            uint texture)
        {
            Gl.glPushMatrix();
            Gl.glTranslated(10 + translateX, -20 + translateY, 63.8);
            Gl.glRotated(rotate, 0, 0, 1);
            Gl.glPushMatrix();
            setColor(0.8f, 0.8f, 0.8f);
            Gl.glScalef(1.5f, 0.5f, 1f);
            Glut.glutSolidCube(30);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireCube(30);
            Gl.glPopMatrix();

            Gl.glPushMatrix();
            Gl.glTranslated(0, 0, -26);
            setColor(0.8f, 0.8f, 0.8f);
            Gl.glScalef(1, 0.5f, 0.15f);
            Glut.glutSolidCube(30);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireCube(30);
            Gl.glPopMatrix();

            Gl.glPushMatrix();
            Gl.glTranslated(0, 0, -19);
            setColor(0.8f, 0.8f, 0.8f);
            Gl.glScalef(0.3f, 0.3f, 0.4f);
            Glut.glutSolidCube(30);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireCube(30);
            Gl.glPopMatrix();

            Gl.glPushMatrix();
            Gl.glTranslated(25, 11, 40);
            Gl.glRotated(180, 0, 1, 0);
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glBindTexture(Gl.GL_TEXTURE_2D, texture);
            Gl.glPushMatrix();
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glVertex3d(5, -20, 52);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(45, -20, 52);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(45, -20, 27);
            Gl.glTexCoord2f(1, 1);
            Gl.glVertex3d(5, -20, 27);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();
            Gl.glPopMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
            Gl.glBegin(Gl.GL_LINES);
            drowLevy(0, 0, 100, 100, 15); //вызов функции вырисовки
            Gl.glEnd();
            Gl.glPopMatrix();

        }
        void drowLevy(int x1, int y1, int x2, int y2, int i)
        {
            if (i == 0)
            {
                Gl.glColor3f(0, 0, 0);
                Gl.glVertex2i(x1, y1); //координаты вырисовываемого 
                Gl.glVertex2i(x2, y2); //отрезка
            }
            else
            {
                int x3 = (x1 + x2) / 2 - (y2 - y1) / 2; //координаты
                int y3 = (y1 + y2) / 2 + (x2 - x1) / 2; //точки излома
                drowLevy(x1, y1, x3, y3, i - 1);
                drowLevy(x3, y3, x2, y2, i - 1);
            }
        }


        //Календарь
        public void drawCalendar(uint texture)
        {
            Gl.glPushMatrix();
            Gl.glTranslated(25, 20, 120);
            Gl.glRotated(180, 0, 1, 0);
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glBindTexture(Gl.GL_TEXTURE_2D, texture);
            Gl.glPushMatrix();
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glVertex3d(-5, -22, 60);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(85, -22, 60);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(85, -22, 0);
            Gl.glTexCoord2f(1, 1);
            Gl.glVertex3d(-5, -22, 0);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();
            Gl.glPopMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();

        }


        //Курсор
        public void drawCursor(double translateX, double translateZ)
        {
            Gl.glPushMatrix();
            setColor(1, 1, 1);
            Gl.glTranslated(101 + translateX, -8.5, 73 + translateZ);
            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glVertex3d(0, -22, 0);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(0, -22, -3);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(3, -22, -2);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();
            Gl.glRotated(-20, 0, 1, 0);
            Gl.glTranslated(-1, 0, -0.5);
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glVertex3d(1, -22, -3.5);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(2, -22, -3.5);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(2, -22, -2);
            Gl.glTexCoord2f(1, 1);
            Gl.glVertex3d(1, -22, -2);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();
            Gl.glPopMatrix();
        }

        //Кресло
        public void drawChair(Worker worker)
        {
            Gl.glPushMatrix();
            Gl.glTranslated(80, -100, 20);
            Gl.glRotated(0 - worker.rotate, 0, 0, 1);
            for (int i =0; i<2; i++)
            {
                Gl.glPushMatrix();
                setColor(0, 0, 0f);
                Gl.glTranslated(0, - i * 10, 20 * i);
                Gl.glRotated(90 *i, 1, 0, 0);
                Gl.glScalef(0.5f, 0.7f, 0.3f);
                Glut.glutSolidCylinder(30, 30, 20, 12);
                Gl.glColor3f(0, 0, 0);
                Gl.glLineWidth(2f);
                Glut.glutWireCylinder(30, 30, 20, 12);
                Gl.glPopMatrix();
            }

            for (int i = 0; i <3; i++)
            {
                Gl.glPushMatrix();
                setColor(0, 0, 0f);
                Gl.glTranslated(0, 0, -15);
                if (i ==1)
                Gl.glRotated(90, 0, 0, 1);
                else if (i==2) Gl.glRotated(90, 1, 0, 0);
                Gl.glScalef(0.2f, 1.2f, 0.15f);
                Glut.glutSolidCube(30);
                Gl.glColor3f(0, 0, 0);
                Gl.glLineWidth(2f);
                Glut.glutWireCube(30);
                Gl.glPopMatrix();
            }

            drawWorker(worker);


            Gl.glPopMatrix();
        }

        //Работник
        public void drawWorker(Worker worker)
        {
            Gl.glPushMatrix();
            Gl.glTranslated(0, 0, 10);
            Gl.glRotated(0 - worker.rotate, 0, 0, 1);
            Gl.glPushMatrix();
            setColor(0.8f, 0.8f, 0.8f);
            Gl.glTranslated(0, 10, 0);
            Gl.glScalef(0.5f, 0.5f, 1.7f);
            Glut.glutSolidCone(30, 30, 20, 12);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireCone(30, 30, 20, 12);
            Gl.glPopMatrix();

            Gl.glPushMatrix();
            setColor(0.8f, 0.8f, 0.8f);
            Gl.glTranslated(0, 10, 40);
            Gl.glScalef(0.4f, 0.4f, 0.4f);
            Glut.glutSolidSphere( 30, 20, 12);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireSphere(30, 20, 12);
            Gl.glPopMatrix();

            Gl.glPushMatrix();
            Gl.glTranslated(0, 20,43);

            Gl.glPushMatrix();
            Gl.glTranslated(0, 0, -3);
            if (worker.workerState == WorkerState.Speaking)
            {
                for (int i = 0; i < 2; i++)
                {
                    Gl.glPushMatrix();
                    if (i == 0)
                    {
                        Gl.glTranslated(0, 0, 0);
                        Gl.glRotated(-45, 0, 1, 0);
                    }
                    else
                    {
                        Gl.glTranslated(0, 0, 0);
                        Gl.glRotated(45, 0, 1, 0);
                    }
                    
                    Gl.glLineWidth(6f);

                    Gl.glBegin(Gl.GL_LINES);
                    Gl.glVertex3d(0, 0, 2);
                    Gl.glVertex3d(0, 0, 15);
                    Gl.glEnd();
                    Gl.glPopMatrix();
                }
                Gl.glTranslated(5, 2, -3);
                Gl.glRotated(-90, 0, 1, 0);
                Gl.glBegin(Gl.GL_LINES);
                Gl.glVertex3d(0, 0, 2);
                Gl.glVertex3d(0, 0, 8);
                Gl.glEnd();

            }
            Gl.glPopMatrix();

            Gl.glScalef(0.4f, 0.2f, 0.4f);
            for (int i = 0; i<2; i++)
            {
                setColor(0,0,0);
                Gl.glTranslated(13 - 40*i, 0, 0);
                
                Glut.glutSolidSphere(5, 20, 12);
                Gl.glColor3f(0, 0, 0);
                Gl.glLineWidth(2f);
                Glut.glutWireSphere(5, 20, 12);
                
            }
            Gl.glPopMatrix();
            Gl.glPushMatrix();
            setColor(1, 0, 0);
            Gl.glTranslated(-3, 37.5, 37);
            Gl.glRotated(22, 1, 0, 0);
            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glVertex3d(0, -22, 0);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(2, -22, -5);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(4, -22, 0);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();

            Gl.glBegin(Gl.GL_QUADS);
            Gl.glVertex3d(2, -22, -4);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(4, -22, -10);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(2, -22, -20);
            Gl.glTexCoord2f(1, 1);
            Gl.glVertex3d(0, -22, -10);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();
            Gl.glPopMatrix();
            Gl.glPopMatrix();
        }

        //Самолётик
        public void drawPlane(Plane plane)
        {

            Gl.glPushMatrix();
            
            setColor(1, 1, 1);
            switch (plane.planeState)
            {
                case PlaneState.Waiting:
                    Gl.glTranslated(100, -70, 47);
                    break;
                case PlaneState.Flying:
                    Gl.glTranslated(100 - plane.translate, -70 + plane.translate, 47);
                    break;
                case PlaneState.Falling:
                    Gl.glTranslated(60, -30, 50 - plane.translate);
                    break;
                case PlaneState.Lying:
                    Gl.glTranslated(60, -30, 5);
                    break;
            }
            
            Gl.glRotated(-45, 0, 0, 1);
            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glVertex3d(70, -22, 0);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(100, -15, 0);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(90, -22, 0);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();

            Gl.glTranslated(0, 0, 0);
            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glVertex3d(70, -22, 0);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(90, -22, 0);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(100, -29, 0);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();

            Gl.glTranslated(0, 0, 0);
            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glVertex3d(70, -22, 0);
            Gl.glTexCoord2f(0, 0);
            Gl.glVertex3d(90, -22, -10);
            Gl.glTexCoord2f(0, 1);
            Gl.glVertex3d(90, -22, 0);
            Gl.glTexCoord2f(1, 0);
            Gl.glEnd();

            Gl.glPushMatrix();
            setColor(0.5f, 0.5f, 0.5f);
            Gl.glTranslated(0, 0, 0.5);
            Gl.glLineWidth(3f);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3d(70.5, -22, 0);
            Gl.glVertex3d(90, -22, 0);
            Gl.glEnd();
            Gl.glPopMatrix();
            Gl.glPopMatrix();
        }

        public void drawInkwell(Inkwell inkwell)
        {
            
            Gl.glPushMatrix();

            Gl.glTranslated(-50, -140, 40);
            if (!inkwell.isStay) Gl.glRotated(90, 0, 1, 0);
                Gl.glPushMatrix();
            setColor(0.13f, 0.08f, 0.17f);
            Gl.glScalef(0.4f, 0.5f, 0.4f);
            Glut.glutSolidSphere(15, 20, 12);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireSphere(15, 20, 12);
            Gl.glPopMatrix();

            Gl.glPushMatrix();
            Gl.glTranslated(0, 0, 5);
            setColor(0.13f, 0.08f, 0.17f);
            Gl.glScalef(0.4f, 0.4f, 0.4f);
            Glut.glutSolidTorus(5,10, 20, 12);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireTorus(5,10, 20, 12);
            Gl.glPopMatrix();

            Gl.glPopMatrix();

            if (inkwell.isSpilled)
            {
                Gl.glPushMatrix();
                Gl.glTranslated(-35, -140, 36);
                setColor(0.03f, 0.08f, 0.17f);
                Gl.glScalef(0.7f, 0.7f, 0.1f);
                Glut.glutSolidSphere(15, 20, 12);
                Gl.glColor3f(0, 0, 0);
                Gl.glLineWidth(2f);
                Glut.glutWireSphere(15, 20, 12);
                Gl.glPopMatrix();
            }
            
        }

        public void drawPendulum(Pendulum pendulum)
        {
            Gl.glPushMatrix();
            Gl.glTranslated(-30, -165, 39);
            Gl.glPushMatrix();
            setColor(0.13f, 0.09f, 0.08f);
            Gl.glScalef(0.5f, 0.7f, 0.2f);
            Glut.glutSolidCube(30);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireCube(30);
            Gl.glPopMatrix();

            for (int i = 0; i <4; i++)
            {
                Gl.glPushMatrix();
                setColor(0.5f, 0.5f, 0.5f);
                Gl.glTranslated(-5, 13, 88);
                if (i == 1) Gl.glTranslated(12,0,0);
                else if (i == 2) Gl.glTranslated(12, 15, 0);
                else if (i == 3) Gl.glTranslated(0, 15, 0);
                Gl.glRotated(90, 0, 1, 0);
                Gl.glLineWidth(5f);
                Gl.glBegin(Gl.GL_LINES);
                Gl.glVertex3d(70.5, -22, 0);
                Gl.glVertex3d(90, -22, 0);
                Gl.glEnd();
                Gl.glPopMatrix();
            }

            for (int i = 0; i < 2; i++)
            {
                Gl.glPushMatrix();
                setColor(0.5f, 0.5f, 0.5f);
                Gl.glTranslated(-27 + i*12, 0, 18);
                Gl.glRotated(90, 0, 0, 1);
                Gl.glLineWidth(5f);
                Gl.glBegin(Gl.GL_LINES);
                Gl.glVertex3d(-9.5, -22, 0);
                Gl.glVertex3d(6.5, -22, 0);
                Gl.glEnd();
                Gl.glPopMatrix();
            }

            for (int i = 0; i < 5; i++)
            {
                Gl.glPushMatrix();
                Gl.glTranslated(3, -8 + i*3 , 10);
                if (i > 2) Gl.glRotated(180, 0, 0, 1);
                drawBall(pendulum.balls[i]);
                Gl.glPopMatrix();
            }
            
            Gl.glPopMatrix();
        }

        private void drawBall(Coord coord)
        {
            setColor(0.5f, 0.5f, 0.5f);
            Gl.glTranslated(0,0 + coord.translateY,0 + coord.translateZ);
            Gl.glScalef(0.4f, 0.4f, 0.4f);
            Glut.glutSolidSphere(4, 20, 12);
            Gl.glColor3f(0, 0, 0);
            Gl.glLineWidth(2f);
            Glut.glutWireSphere(4, 20, 12);
        }

        //Задать цвет
        private void setColor(float R, float G, float B)
        {
            RGB color = new RGB(R - deltaColor, G - deltaColor, B - deltaColor);
            Gl.glColor3f(color.getR(), color.getG(), color.getB());
        }
    }

    class RGB
    {
        private float R;
        private float G;
        private float B;

        public RGB(float R, float G, float B)
        {
            this.R = R;
            this.G = G;
            this.B = B;
        }

        public float getR()
        {
            return R;
        }

        public float getG()
        {
            return G;
        }

        public float getB()
        {
            return B;
        }
    }
    }
